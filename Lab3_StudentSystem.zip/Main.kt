import kotlinx.coroutines.*

// Клас Student
class Student private constructor(private var _name: String) {
    private var _age: Int = 0
    private var _grades: List<Int> = listOf()

    constructor(name: String, age: Int, grades: List<Int>) : this(name) {
        this.age = age
        this._grades = grades
    }

    init {
        println("Student object created: $_name")
    }

    var name: String
        get() = _name
        set(value) {
            _name = value.trim().replaceFirstChar { it.uppercase() }
        }

    var age: Int
        get() = _age
        set(value) {
            if (value >= 0) _age = value
        }

    val isAdult: Boolean
        get() = _age >= 18

    val status: String by lazy {
        if (isAdult) "Adult" else "Minor"
    }

    fun getAverage(): Double {
        return if (_grades.isNotEmpty()) _grades.average() else 0.0
    }

    fun processGrades(operation: (Int) -> Int) {
        _grades = _grades.map(operation)
    }

    fun updateGrades(grades: List<Int>) {
        _grades = grades
    }

    operator fun plus(other: Student): Student {
        val combinedGrades = _grades + other._grades
        return Student(this.name, maxOf(this.age, other.age), combinedGrades)
    }

    operator fun times(multiplier: Int): Student {
        val newGrades = _grades.map { it * multiplier }
        return Student(this.name, this.age, newGrades)
    }

    override operator fun equals(other: Any?): Boolean {
        if (other !is Student) return false
        return this.name == other.name && this.getAverage() == other.getAverage()
    }

    fun info() {
        println("Ім'я: $name | Вік: $age | Дорослий: $isAdult | Статус: $status")
        println("Оцінки: $_grades | Середня: ${getAverage()}")
    }
}

// Клас Group
class Group(vararg students: Student) {
    private val studentList = students.toList()

    operator fun get(index: Int): Student = studentList[index]

    fun getTopStudent(): Student? = studentList.maxByOrNull { it.getAverage() }
}

// Симуляція отримання оцінок із сервера
suspend fun fetchGradesFromServer(): List<Int> {
    delay(2000)
    return listOf(90, 80, 70, 85, 95)
}

// Основна функція
fun main() = runBlocking {
    val student1 = Student(" ільїн ")  // secondary constructor
    student1.age = 19
    println()

    val gradesFromServer = async { fetchGradesFromServer() }
    student1.updateGrades(gradesFromServer.await())

    val student2 = Student(name = "Олена", age = 20, grades = listOf(100, 100, 90))
    val student3 = Student(name = "Артем", age = 17, grades = listOf(60, 70, 80))

    val combined = student1 + student2
    val boosted = student3 * 2

    println("\n== Інформація про студентів ==")
    student1.info()
    student2.info()
    student3.info()
    println("\n== Комбінований студент ==")
    combined.info()
    println("\n== Помножені оцінки ==")
    boosted.info()

    println("\nstudent1 == student2: ${student1 == student2}")
    println("student2 == student2: ${student2 == student2}")

    val group = Group(student1, student2, student3)
    println("\nНайкращий студент у групі:")
    group.getTopStudent()?.info()
}